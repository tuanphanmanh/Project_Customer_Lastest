﻿using Syncfusion.Pdf;
using Syncfusion.Pdf.Graphics;
using Syncfusion.Pdf.Parsing;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReplaceImageSample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Load the PDF document
            PdfLoadedDocument loadedDocument = new PdfLoadedDocument("../../Data/Input.pdf");

            //Load the PDF page
            PdfLoadedPage loadedPage = loadedDocument.Pages[0] as PdfLoadedPage;

            //Create an image instance
            PdfBitmap image = new PdfBitmap("../../Data/Essen PDF.jpg");
            //Replace the image
            loadedPage.ReplaceImage(0, image);

            image = new PdfBitmap("../../Data/Essen DocIO.jpg");
            loadedPage.ReplaceImage(1, image);

            image = new PdfBitmap("../../Data/Essen XlsIO.jpg");
            loadedPage.ReplaceImage(2, image);

            //Save the document
            loadedDocument.Save("ReplacedImage.pdf");

            //Close the document
            loadedDocument.Close(true);

            //This will open the PDF file so, the result will be seen in default PDF viewer 
            Process.Start("ReplacedImage.pdf");
        }
    }
}
